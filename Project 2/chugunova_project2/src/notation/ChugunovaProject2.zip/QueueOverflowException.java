//Sousanna Chugunova
//Dr.Thai
//CMSC204
package notation;

public class QueueOverflowException extends Exception {
    private static final long serialVersionUID = 1L;

	public QueueOverflowException(String message) {
        super(message);
    }
}
