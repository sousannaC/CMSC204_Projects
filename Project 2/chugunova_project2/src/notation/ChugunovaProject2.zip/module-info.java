/**
 * 
 */
/**
 * 
 */
module chugunova_project2 {
	requires transitive javafx.graphics;
	requires org.junit.jupiter.api;
	requires javafx.controls;
	requires java.desktop;
	requires junit;
	requires org.junit.jupiter.engine;
	requires jdk.incubator.vector;
    requires javafx.fxml;
    


    exports notation to javafx.graphics;

}