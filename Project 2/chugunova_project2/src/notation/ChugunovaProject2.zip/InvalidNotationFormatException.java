//Sousanna Chugunova
//Dr.Thai
//CMSC204
package notation;

public class InvalidNotationFormatException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidNotationFormatException(String message) {
        super(message);
    }
}
