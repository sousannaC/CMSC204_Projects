//sousanna chugunova
//CMSC204
//Dr.Thai
module Chugunova_Project5 {

	exports main;
	
	requires javafx.base;

	requires java.desktop;
	requires javafx.controls;
	requires junit;
	requires org.junit.jupiter.api;
	requires javafx.fxml;
	requires transitive javafx.graphics; 

 
}