//programmer:Sousanna Chugunova
//CMSC204 
//Dr.Thai
module abc {
	requires junit;
	requires javafx.graphics;
	requires java.desktop;
	requires javafx.controls;
	requires javafx.base;
	requires org.junit.jupiter.api;

}