package abc;
public class NoSpecialCharacterException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSpecialCharacterException(String message) {
        super(message);
    }

	}

